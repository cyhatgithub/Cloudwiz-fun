import com.cloudmon.metrics.CCounter;
import com.cloudmon.metrics.CGauge;
import com.cloudmon.metrics.CMetric;
import com.cloudmon.metrics.CStatsCollector;

import java.util.Random;

public class HelloWorld {
	private final CCounter fooCount = CStatsCollector.createCounter("fooCount");
	private final CMetric fooDurationMs = CStatsCollector.createMetric("fooDurationMs");
	private final CGauge fooRandom = CStatsCollector.createGauge("fooRandom");
	
	public HelloWorld() {}

	public void foo(int sleepMs) throws InterruptedException {
		fooCount.inc();

		long startMs = System.currentTimeMillis();
		try {
			System.out.print(".");
			Thread.sleep(sleepMs);
		} catch (InterruptedException e) {
		} finally {
			long durationMs = System.currentTimeMillis() - startMs;
			fooDurationMs.add(durationMs);
		}

		if (sleepMs % 2 == 0) {
			fooRandom.set(sleepMs);
		}
	}
	
	public static void main(String[] args) throws Exception {
		int n = args.length > 0 ? Integer.parseInt(args[0]) : 100;	

		// To open a Http endpoint. Must have before using any metrics.
		CStatsCollector.start(9999);
		
		HelloWorld helloWorld = new HelloWorld();
		
		Random r = new Random();
		for (int i = 0; i < n; i++) {
			int rInt = r.nextInt(n);
			helloWorld.foo(rInt);
		}	
        }
}
